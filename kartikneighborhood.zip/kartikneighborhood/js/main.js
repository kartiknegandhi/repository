

var map;
var bounds;
var largeInfowindow;
var marker;
// Create a new blank array for all the listing markers.
var markers = [];
      
var locations = [ //storing the detailed info of all the locations whose markers are to be placed
    {
        title: 'Mithibai ',
        location: {
            lat: 19.1031174,
            lng: 72.8373278
        },
        address: 'North South Road Number 1, Suvarna Nagar, Vile Parle West, Mumbai, Maharashtra 400056, India',
        phone: "022 4233 9001",
        url: 'www.mithibai.ac.in/',
        place: 'college'
    },
    {
        title: 'Maxus ',
        location: {
            lat: 19.2960876,
            lng: 72.8485584
        },
        address: '150 Feet Road, Maxus Mall Road, Near Railway Flyover, Maxus Mall, Opposite Salasar Bridge Bhoomi, Bhayandar West, Wadi Bandar, Mazgaon, Mumbai, Maharashtra 401101, India',
        phone: "022 2815 2221",
        url: 'www.maxus.com/',
        place: 'mall'
    },
    {
        title: 'High Street Pheonix ',
        location: {
            lat: 18.9940439,
            lng: 72.8250901
        },
        address: '462, Senapati Bapat Marg, Lower Parel, Mumbai, Maharashtra 400013, India',
        phone: "022 4333 9994",
        url: 'www.highstreetphoenix.com/', 
        place: 'mall'
    },
    {
        title: 'Pheonix Market City ',
        location: {
            lat: 19.0866536,
            lng: 72.8889137
        },
        address: 'Lal Bahadur Shastri Marg, Kurla West, Mumbai, Maharashtra 400070, India',
        phone: "022 6180 1100",
        url: 'https://www.phoenixmarketcity.com/mumbai',
        place: 'mall'
    },
    {
        title: 'Khalsa College ',
        location: {
            lat: 19.025201,
            lng: 72.8566393
        },
        address: 'Nathalal Parekh Marg, Matunga East, Mumbai, Maharashtra 400019, India',
        phone: "022 2409 6234",
        url: 'www.gnkhalsa.edu.in/',
        place: 'college'
    },
    {
        title: 'Metro ',
        location: {
            lat: 18.9430131,
            lng: 72.8288781
        },
        address: 'M.G.Road, Dhobitalao Junction, Mumbai, Maharashtra 400020, India',
        phone: "080802 11111",
        url: '-',
        place:'theatre'
    },
    {
        title: ' Sterling',
        location: {
            lat: 18.9383381,
            lng: 72.83268180000002
        },
        address: '65, Murzban Road, Azad Maidan, Fort, Mumbai, Maharashtra 400001, India',
        phone: "022 6622 0016",
        url: '-',
        place:'theatre'
    },
    {
        title: 'INOX ',
        location: {
            lat:  18.926773,
            lng: 72.822559
        },
        address: 'CR2 Mall, Barrister Rajni Patel Marg, Nariman Point, Mumbai, Maharashtra 400021, India',
        phone: "22 4062 69 00",
        url: 'https://www.inoxmovies.com/',
        place:'theatre'
    },

    {
        title: 'Narsee Monjee',
        location: {
            lat: 19.1036726,
            lng: 72.83716629999999
        },
        address: 'Bhaktivedanta Swami Marg, Gulmohar Road, Juhu Scheme, Vile Parle West, Mumbai, Maharashtra 400056, India',
        phone: "022 4233 8000",
        url: 'www.nmcollege.in',
        place: 'college'
    },
    {
        title: 'DJ Sanghvi',
        location: {
            lat: 19.1075386,
            lng: 72.83704139999999
        },
        address: 'Plot No.U-15, J.V.P.D. Scheme, Bhaktivedanta Swami Marg, Vile Parle West, Mumbai, Maharashtra 400056, India',
        phone: "94631 58608",
        url: 'www.djsce.ac.in/',
        place: 'college'
    },
    {
        title: 'Hassaram Rijhumal ',
        location: {
            lat: 18.929669,
            lng: 72.8267539
        },
        address: '123, Dinshaw Wachha Road, Churchgate, Mumbai, Maharashtra 400020, India',
        phone: "022 2287 6115",
        url: 'www.hrcollege.edu/',
        place: 'college'
    },
    {
        title: 'Jai Hind',
        location: {
            lat: 18.9345107,
            lng: 72.82521050000001
        },
        address: 'A Road, Churchgate, Mumbai, Maharashtra 400020, India',
        phone: "022 2204 0256",
        url: 'www.jaihindcollege.com/',
        place: 'college'
    },
    {
        title: 'Kishinchand Chellaram',
        location: {
            lat: 18.9296144,
            lng: 72.82711619999999
        },
        address: '124, Dinshaw Wachha Road, Vidyasagar Principal K. M. Kundnani Chowk, Churchgate, Mumbai, Maharashtra 400020, India',
        phone: "022 6698 1000",
        url: 'www.kccollege.edu.in/',
        place: 'college'
    },

    {
        title: 'KJ Somaiya College Of Engineering',
        location: {
            lat: 19.073041,
            lng: 72.899697
        },
        address: 'Vidyanagar, Vidya Vihar East, Vidyavihar, Mumbai, Maharashtra 400077, India',
        phone: "022 6644 9191",
        url: 'https://www.somaiya.edu/kjsce',
        place: 'college'
    }
];

      function initMap() {
        largeInfowindow = new google.maps.InfoWindow();
        // Constructor creates a new map - only center and zoom are required.
        map = new google.maps.Map(document.getElementById('map-canvas'), {
          center: {lat:  18.8928676, lng: 72.7758729},
          zoom: 13,
        scrollwheel: true      
          });
        

            // The following group uses the location array to create an array of markers on initialize.
        for (i = 0; i < locations.length; i++) {
            marker = new google.maps.Marker({
                map:map,
          // Get the position from the location array.
          position: locations[i].location,
          title: locations[i].title,
          // Create a marker per location, and put into markers array.
          address: locations[i].address,
         phone: locations[i].phone,
         url: locations[i].url,
         animation: google.maps.Animation.DROP,
         draggable: true
          });
            locations[i].marker = marker;
          // Push the marker to our array of markers.
          markers.push(marker);
          // Create an onclick event to open an infowindow at each marker.
          marker.addListener('click', function() {
            animateMarker(this);
            populateInfoWindow(this, largeInfowindow);
          });
        }
    //specifing lat lng bounds 
  var bounds = new google.maps.LatLngBounds();
  //Fits the markers as window resizes
  google.maps.event.addDomListener(window, 'load', displayMarkerList);
  google.maps.event.addDomListener(window, 'resize', displayMarkerList);
      
      //Displays markers on the listed location
  function displayMarkerList () {
    
          for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
            bounds.extend(markers[i].position);
          }
      map.fitBounds(bounds);      
    }   
  ko.applyBindings(new viewModel());
}
// Animation for marker
function animateMarker(marker) {

  marker.setAnimation(google.maps.Animation.DROP);
    setTimeout(function(){
        marker.setAnimation(null);
    }, 3000);
}
 // This function populates the infowindow when the marker is clicked.
      function populateInfoWindow(marker, infowindow) {
        // Check to make sure the infowindow is not already opened on this marker.
        if (infowindow.marker != marker) {
          infowindow.marker = marker;
          infowindow.setContent('<div>' + marker.title + '</div>');
          infowindow.open(map, marker);
          // Make sure the marker property is cleared if the infowindow is closed.
          infowindow.addListener('closeclick', function() {
            infowindow.marker = null;
          });
        }
      }

   
      function errorHandling() {
    alert("Issue loading the maps");
    $('#map-canvas').html("Please try again later"); 
}


 function mallselect() {
        for (var i = 0; i < markersArray.length; i++) {
            if(markers[i].place === mall) {
                markersArray[i].setMap(map);
            }
            else {
                markersArray[i].setMap(null);
            }
        }
    };
    function collegeselect() {
        for (var i = 0; i < markersArray.length; i++) {
            if(markers[i].place === college) {
                markersArray[i].setMap(map);
            }
            else {
                markersArray[i].setMap(null);
            }
        }
    };
     function theatreselect() {
        for (var i = 0; i < markersArray.length; i++) {
            if(markers[i].place === theatre) {
                markersArray[i].setMap(map);
            }
            else {
                markersArray[i].setMap(null);
            }
        }
    };

//ViewModel function     
var viewModel = function() {
    var self = this;
    this.locationList = ko.observableArray([]);
    this.filterIndicator = ko.observable("");
    this.filterInfo = ko.observable(false);
    this.displayFilter = ko.observable("options-box");
     this.locationList = ko.observableArray(markers);



      this.filtermall = function() {
        var len = self.locationList().length;
        for (var i = 0; i < len; i++) {
            if(self.locationList()[i].place() === mall) {
                self.locationList()[i].listVisible(true);
                mallselect();
            }
            else {
                self.locationList()[i].listVisible(false);
            }
        }
    };
      this.filtercollege = function() {
        var len = self.locationList().length;
        for (var i = 0; i < len; i++) {
            if(self.locationList()[i].place() === college) {
                self.locationList()[i].listVisible(true);
                collegeselect();
            }
            else {
                self.locationList()[i].listVisible(false);
            }
        }
    };
      this.filtertheatre = function() {
        var len = self.locationList().length;
        for (var i = 0; i < len; i++) {
            if(self.locationList()[i].place() = theatre) {
                self.locationList()[i].listVisible(true);
                theatreselect();
            }
            else {
                self.locationList()[i].listVisible(false);
            }
        }
    };
     this.openInfo = function(thisList) {
        var thisId = this.locationId();
        var newId = thisId.slice(-1);
        fillInfoWindow(markersArray[newId], infoWindow);
    };
};
    ko.applyBindings(new viewModel());