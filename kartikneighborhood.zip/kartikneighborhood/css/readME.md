##Udacity Neighborhood Map
By:Kartik Negandhi.
Email:kartiknegandhi@gmail.com

### Getting started
<ol><li>	 Download the zip file and extract it</li>
<li>	 Run index.html.</li>
<li>	 The given map shows a zoomed in image of mumbai anda list of locations, click on any of the markers and get all  the information about it.</li>
<li> A search option is also provided to filter the visible markers on the map</li>
</ol>

### References:
*http://www.w3schools.com/colors/colors_picker.asp
*https://discussions.udacity.com/t/neighborhood-map-zooming-issue-in-map-marker-info-and-js-error-for-wikipedia/213991/4
*http://knockoutjs.com/downloads/knockout-3.4.1.js
*https://developers.google.com/maps/documentation/javascript/examples/marker-animations
*https://developers.google.com/maps/documentation/geocoding/intro
*https://developers.google.com/maps/documentation/geocoding/intro
*https://classroom.udacity.com/nanodegrees/nd001/parts/00113454014/modules/4fd8d440-9428-4de7-93c0-4dca17a36700/lessons/8306134879/concepts/83070348810923
*https://classroom.udacity.com/nanodegrees/nd001/parts/00113454014/modules/4fd8d440-9428-4de7-93c0-4dca17a36700/lessons/8306134879/concepts/83070348810923
*https://classroom.udacity.com/nanodegrees/nd001/parts/00113454014/modules/4fd8d440-9428-4de7-93c0-4dca17a36700/lessons/8304370457/concepts/83122494440923
